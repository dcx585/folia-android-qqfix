import type { SongResult, UnifiedSong } from '../../../types';
import {
    OnlineProviderError,
    type AudioQualityPreference,
    type ChorusRange,
    type JsonValue,
    type MediaId,
    type OnlineMusicProvider,
    type ProviderCatalogRef,
    type ProviderCollection,
    type ProviderHistoryEntry,
    type ProviderPage,
    type ProviderUser,
} from '../../../types/onlineMusic';
import { getSizedCoverUrl } from '../../../utils/coverUrl';
import { parseLyricsByFormat } from '../../../utils/lyrics/parserCore';
import { isPureMusicLyricText } from '../../../utils/lyrics/pureMusic';
import { hasRenderableLyrics } from '../../../utils/lyrics/validity';
import { getPlaybackSongKey } from '../../../utils/appPlaybackGuards';
import { decibelsToLinearPeak, toFiniteNumber } from '../../../utils/replayGain';
import { createProviderSongMetadata } from '../../../utils/songMetadata';
import {
    buildKugouLyricSearchQuery,
    normalizeSongTitleForLyricSearch,
} from '../../../utils/lyrics/searchQuery';
import { removeProviderSessionValue, readProviderSessionValue } from '../providerStorage';
import i18n from '../../../i18n/config';
import {
    getKugouTransportAvailability,
    hasKugouAuthenticatedSearchSession,
    requestKugouAnonymousSearch,
    requestKugou,
    requestKugouLegacyPlayInfo,
} from './kugouTransport';
import { describeKugouLoginFailure, kugouCheckFailure } from './kugouLoginFailure';
import { describeKugouFailure, isKugouTimeout, kugouNoUrlError } from './kugouFailure';
import { errorFields } from '../../../utils/errorText';

// src/services/onlineMusic/kugou/kugouProvider.ts

const valueOf = (raw: any, ...keys: string[]) => {
    for (const key of keys) {
        if (raw?.[key] !== undefined && raw?.[key] !== null) return raw[key];
    }
    return undefined;
};

const KUGOU_CANONICAL_COVER_SIZE = 1024;

// Selects one playable URL without coercing KuGou's candidate URL arrays into a comma-joined path.
const audioUrlOf = (raw: unknown): string | undefined => {
    const values = Array.isArray(raw) ? raw : [raw];
    const candidates = values.flatMap(value => (
        typeof value === 'string' ? value.split(/,\s*(?=https?:\/\/)/i) : []
    ));

    return candidates.find(candidate => {
        try {
            const protocol = new URL(candidate.trim()).protocol;
            return protocol === 'http:' || protocol === 'https:';
        } catch {
            return false;
        }
    })?.trim();
};

const dataOf = (raw: any): any => raw?.data ?? raw?.body?.data ?? raw?.body ?? raw;

// Unwrap the nested envelopes used by the different KuGou recommendation endpoints.
const listOf = (raw: any): any[] => {
    const queue: any[] = [dataOf(raw)];
    const listKeys = [
        'lists', 'list', 'info', 'songs', 'song_list', 'songlist', 'songList', 'audios', 'albums', 'items', 'records',
        'special', 'specials', 'special_list', 'playlist', 'playlists',
        'recommend_list', 'recommendations', 'data', 'result', 'response',
    ];
    const visited = new Set<object>();

    while (queue.length > 0) {
        const current = queue.shift();
        if (Array.isArray(current)) return current;
        if (!current || typeof current !== 'object' || visited.has(current)) continue;
        visited.add(current);

        for (const key of listKeys) {
            const value = current[key];
            if (Array.isArray(value)) return value;
            if (value && typeof value === 'object') queue.push(value);
        }
    }

    return [];
};

const coverOf = (raw: any): string | undefined => {
    // Youth card songs carry the album art in album_info/audio_info; user_pic is only the uploader avatar.
    const value = valueOf(raw?.album_info, 'sizable_cover', 'cover')
        ?? valueOf(raw?.albumInfo, 'sizable_cover', 'cover')
        ?? valueOf(raw?.audio_info?.trans_param, 'union_cover')
        ?? valueOf(raw?.audioInfo?.transParam, 'union_cover')
        ?? valueOf(raw?.trans_param, 'union_cover')
        ?? valueOf(raw, 'sizable_cover', 'Image', 'image', 'img', 'pic', 'picUrl', 'cover', 'coverUrl', 'sizable_avatar');
    if (!value) return undefined;
    const cover = String(value).trim().replace('{size}', String(KUGOU_CANONICAL_COVER_SIZE));
    if (/^\d{8,}\.(?:jpe?g|png|webp)$/i.test(cover)) {
        return `https://c1.kgimg.com/stdmusic/${KUGOU_CANONICAL_COVER_SIZE}/${cover.slice(0, 8)}/${cover}`;
    }
    const secureCover = cover.startsWith('//') ? `https:${cover}` : cover.replace(/^http:/i, 'https:');
    return getSizedCoverUrl(secureCover, KUGOU_CANONICAL_COVER_SIZE);
};

const hashOf = (raw: any): string => String(
    valueOf(raw, 'FileHash', 'fileHash', 'hash', 'Hash', 'audio_hash', 'audioHash', 'kgHash')
    ?? valueOf(raw?.audio_info, 'hash', 'hash_128')
    ?? '',
).toUpperCase();

const isKugouSongPayload = (raw: any): boolean => Boolean(
    valueOf(raw, 'FileHash', 'fileHash', 'hash', 'Hash', 'songid', 'songId', 'SongName', 'songname', 'songName', 'ori_audio_name', 'audio_name')
    ?? valueOf(raw?.base, 'songid', 'songId', 'songname', 'songName')
);

// Finds song arrays even when KuGou wraps recommendations in several data/card envelopes.
const songListOf = (raw: any): any[] => {
    const queue: any[] = [dataOf(raw)];
    const listKeys = [
        'song_list', 'songlist', 'songList', 'songs', 'audios', 'list', 'lists', 'info', 'items',
        'records', 'song_info', 'songInfo', 'data', 'result', 'response',
    ];
    const visited = new Set<object>();

    while (queue.length > 0) {
        const current = queue.shift();
        if (Array.isArray(current)) {
            if (current.some(isKugouSongPayload)) return current;
            current.forEach(item => {
                if (item && typeof item === 'object') queue.push(item);
            });
            continue;
        }
        if (!current || typeof current !== 'object' || visited.has(current)) continue;
        visited.add(current);
        if (isKugouSongPayload(current)) return [current];

        for (const key of listKeys) {
            const value = current[key];
            if (Array.isArray(value)) queue.push(value);
            else if (value && typeof value === 'object') queue.push(value);
        }
    }

    return [];
};

const jsonData = (entries: Array<[string, unknown]>): Record<string, JsonValue> => Object.fromEntries(
    entries.filter((entry): entry is [string, JsonValue] => (
        entry[1] === null || ['string', 'number', 'boolean'].includes(typeof entry[1])
    )),
);

const catalogRef = (
    kind: ProviderCatalogRef['kind'],
    id: unknown,
): ProviderCatalogRef | undefined => (
    id !== undefined && id !== null && String(id) !== ''
        ? { providerId: 'kugou', kind, id: id as MediaId }
        : undefined
);

const normalizeArtists = (raw: any) => {
    const singers = valueOf(raw, 'Singers', 'singers', 'singerinfo', 'authors', 'artists');
    const usesSingerInfo = singers === raw?.singerinfo;
    if (Array.isArray(singers)) {
        return singers.map((artist: any, index: number) => {
            const base = artist?.base ?? artist;
            const authorId = valueOf(base, 'author_id', 'authorId')
                ?? (usesSingerInfo ? valueOf(base, 'id') : undefined);
            return {
                id: authorId ?? `kugou-artist-${index}`,
                name: String(valueOf(base, 'name', 'author_name', 'singername') || ''),
                ...(catalogRef('artist', authorId) ? { catalogRef: catalogRef('artist', authorId) } : {}),
            };
        }).filter(artist => artist.name);
    }
    const names = String(valueOf(raw, 'SingerName', 'singername', 'author_name', 'Singer') || '')
        .split(/[、,&/]/).map(name => name.trim()).filter(Boolean);
    return names.map((name, index) => ({ id: `kugou-artist-${index}-${name}`, name }));
};

const normalizeTimestamp = (value: unknown): number | undefined => {
    if (value === undefined || value === null || value === '') return undefined;
    const numeric = Number(value);
    if (Number.isFinite(numeric)) {
        if (numeric > 0 && numeric < 10000) return Date.UTC(Math.round(numeric), 0, 1);
        return numeric < 1_000_000_000_000 ? numeric * 1000 : numeric;
    }
    const parsed = Date.parse(String(value));
    return Number.isFinite(parsed) ? parsed : undefined;
};

// Some KuGou collection endpoints only expose "artist - title" through audio_name.
const normalizeKugouTitleAndArtists = (rawTitle: string, rawArtists: ReturnType<typeof normalizeArtists>) => {
    if (rawArtists.length > 0) {
        return {
            title: normalizeSongTitleForLyricSearch(rawTitle, rawArtists.map(artist => artist.name).join(', ')),
            artists: rawArtists,
        };
    }

    const combined = rawTitle.match(/^(.+?)\s+-\s+(.+)$/u);
    if (!combined) {
        return { title: rawTitle.trim(), artists: rawArtists };
    }

    const artistNames = combined[1]
        .split(/[、,&/]|\s+(?:feat\.?|ft\.?|featuring)\s+/iu)
        .map(name => name.trim())
        .filter(Boolean);
    if (artistNames.length === 0) {
        return { title: rawTitle.trim(), artists: rawArtists };
    }

    return {
        title: combined[2].trim(),
        artists: artistNames.map((name, index) => ({ id: `kugou-artist-${index}-${name}`, name })),
    };
};

export const normalizeKugouSong = (raw: unknown): UnifiedSong => {
    const item = raw as any;
    const base = item?.base ?? {};
    const audioInfo = item?.audio_info ?? item?.audioInfo ?? {};
    const hash = hashOf(item);
    const rawArtists = normalizeArtists(item);
    const nestedAlbum = valueOf(item, 'album_info', 'albumInfo', 'albuminfo', 'album') ?? {};
    const albumId = valueOf(item, 'AlbumID', 'album_id', 'albumId')
        ?? valueOf(nestedAlbum, 'album_id', 'albumId')
        ?? valueOf(base, 'album_id', 'albumId')
        ?? '';
    const albumCatalogRef = catalogRef('album', albumId);
    const albumName = String(
        valueOf(item, 'AlbumName', 'album_name', 'albumName', 'albumname')
        ?? valueOf(nestedAlbum, 'name', 'album_name', 'albumName')
        ?? valueOf(base, 'album_name', 'albumName')
        ?? ''
    );
    const durationValue = Number(
        valueOf(item, 'Duration', 'duration', 'timelen', 'timeLength', 'timelength', 'time_length')
        ?? valueOf(audioInfo, 'duration', 'timelength', 'duration_128')
        ?? 0,
    );
    const duration = durationValue > 0 && durationValue < 10000 ? durationValue * 1000 : durationValue;
    const mixSongId = valueOf(item, 'MixSongID', 'mixsongid', 'mixSongId')
        ?? valueOf(base, 'MixSongID', 'mixsongid', 'mixSongId');
    const albumAudioId = valueOf(item, 'album_audio_id', 'albumAudioId')
        ?? valueOf(base, 'album_audio_id', 'albumAudioId');
    const providerData = jsonData([
        ['hash', hash],
        ['mixSongId', mixSongId],
        ['albumAudioId', albumAudioId],
        ['catalogLookupId', albumAudioId ?? mixSongId],
        ['albumId', albumId],
        ['fileId', valueOf(item, 'FileID', 'fileid', 'file_id')],
    ]);
    const rawTitle = String(valueOf(
        item,
        'SongName', 'songname', 'songName',
        'ori_audio_name', 'oriAudioName',
        'OriSongName', 'ori_song_name', 'oriSongName',
        'FileName', 'filename', 'fileName',
        'name', 'audio_name',
    ) ?? valueOf(audioInfo, 'ori_audio_name', 'oriAudioName', 'audio_name', 'audioName')
        ?? valueOf(base, 'SongName', 'songname', 'songName', 'audio_name', 'audioName') ?? '');
    const { title, artists } = normalizeKugouTitleAndArtists(rawTitle, rawArtists);

    const album = {
        id: albumId,
        name: albumName,
        coverUrl: coverOf(item),
        ...(albumCatalogRef ? { catalogRef: albumCatalogRef } : {}),
    };

    return {
        id: hash,
        name: title,
        artists,
        album,
        durationMs: duration,
        kgHash: hash,
        sourceRef: { kind: 'online', providerId: 'kugou', mediaId: hash, providerData },
    };
};

const KUGOU_RECOMMENDATION_PAGE_SIZE = 30;
const KUGOU_MAX_PAGE_SIZE = 100;
const KUGOU_RECOMMENDATION_CARDS = [
    { id: 3006, name: 'VIP 专属推荐' },
    { id: 3001, name: '私人专属好歌' },
    { id: 3004, name: '小众宝藏佳作' },
    { id: 3014, name: '喜欢这首歌的 TA 也喜欢' },
    { id: 3101, name: '概念 er 新推' },
    { id: 3005, name: '潮流尝鲜' },
] as const;

const kugouRecommendationTrackCache = new Map<number, UnifiedSong[]>();

// Loads one KuGou recommendation card and keeps its normalized songs for the virtual playlist.
const getKugouRecommendationCard = async (cardId: number, pagesize = KUGOU_RECOMMENDATION_PAGE_SIZE) => {
    const response = await requestKugou('top_card_youth', { card_id: cardId, pagesize });
    const songs = songListOf(response)
        .map(normalizeKugouSong)
        .filter(song => song.id);
    kugouRecommendationTrackCache.set(cardId, songs);
    return { response, songs };
};

const getKugouRecommendationCardId = (collection: ProviderCollection | undefined, id?: MediaId): number | undefined => {
    const providerCardId = collection?.providerData?.cardId;
    const cardId = Number(providerCardId ?? String(id ?? '').match(/^kugou-card-(\d+)$/u)?.[1]);
    return Number.isInteger(cardId) && cardId > 0 ? cardId : undefined;
};

const isKugouVirtualRecommendation = (collection: ProviderCollection | undefined): boolean => (
    collection?.providerId === 'kugou' && collection.providerData?.virtualRecommendation === true
);

// Builds the Omni playlist object used by the radio surface for song-card recommendations.
const createKugouRecommendationCollection = (
    card: (typeof KUGOU_RECOMMENDATION_CARDS)[number],
    response: any,
    songs: UnifiedSong[],
): ProviderCollection => {
    const data = dataOf(response);
    const name = String(valueOf(data, 'card_name', 'cardName', 'module_name', 'moduleName', 'title', 'name') || card.name);
    const description = valueOf(data, 'description', 'desc', 'subtitle', 'sub_title');

    return {
        providerId: 'kugou',
        id: `kugou-card-${card.id}`,
        name,
        type: 'playlist',
        ...(songs[0]?.album.coverUrl ? { coverUrl: songs[0].album.coverUrl } : {}),
        ...(description ? { description: String(description) } : {}),
        trackCount: songs.length,
        providerData: {
            virtualRecommendation: true,
            cardId: card.id,
        },
    };
};

const getKugouRecommendationPage = async (
    collection: ProviderCollection | undefined,
    limit: number,
    offset: number,
): Promise<ProviderPage<UnifiedSong> | null> => {
    const cardId = getKugouRecommendationCardId(collection);
    if (!isKugouVirtualRecommendation(collection) || cardId === undefined) return null;

    const songs = kugouRecommendationTrackCache.get(cardId)
        ?? (await getKugouRecommendationCard(cardId)).songs;
    const items = songs.slice(offset, offset + limit);
    return {
        items,
        total: songs.length,
        hasMore: offset + items.length < songs.length,
        nextOffset: offset + items.length,
    };
};

const kugouCatalogMetadataRequests = new Map<string, Promise<any | null>>();

const getKugouCatalogLookupId = (song: SongResult): string => {
    const sourceRef = song.sourceRef?.kind === 'online' && song.sourceRef.providerId === 'kugou'
        ? song.sourceRef
        : null;
    return String(sourceRef?.providerData?.catalogLookupId || '');
};

const requestKugouCatalogMetadata = (lookupId: string): Promise<any | null> => {
    const cached = kugouCatalogMetadataRequests.get(lookupId);
    if (cached) return cached;

    const request = requestKugou('krm_audio', {
        album_audio_id: lookupId,
        fields: 'album_info,authors.base,base,audio_info',
    }).then(
        response => {
            if (kugouCatalogMetadataRequests.get(lookupId) === request) {
                kugouCatalogMetadataRequests.delete(lookupId);
            }
            return listOf(response)[0] ?? null;
        },
        error => {
            if (kugouCatalogMetadataRequests.get(lookupId) === request) {
                kugouCatalogMetadataRequests.delete(lookupId);
            }
            throw error;
        },
    );
    kugouCatalogMetadataRequests.set(lookupId, request);
    return request;
};

const hasMatchingKugouHash = (metadata: any, song: SongResult): boolean => {
    const expectedHash = String(song.kgHash || (
        song.sourceRef?.kind === 'online' ? song.sourceRef.providerData?.hash : ''
    ) || '').toUpperCase();
    if (!expectedHash) return false;

    const audioInfo = metadata?.audio_info ?? metadata?.audioInfo ?? {};
    return [
        valueOf(audioInfo, 'hash', 'FileHash', 'fileHash'),
        valueOf(audioInfo, 'hash_128', 'hash128'),
    ].some(candidate => String(candidate || '').toUpperCase() === expectedHash);
};

// Hydrates canonical KuGou album/artist ids only after KRM metadata matches the song hash.
export const resolveKugouSongCatalogRefs = async (song: UnifiedSong): Promise<UnifiedSong> => {
    const lookupId = getKugouCatalogLookupId(song);
    if (!lookupId) return song;

    const metadata = await requestKugouCatalogMetadata(lookupId);
    if (!metadata || !hasMatchingKugouHash(metadata, song)) return song;

    const base = metadata.base ?? {};
    const albumInfo = metadata.album_info ?? metadata.albumInfo ?? {};
    const albumId = valueOf(albumInfo, 'album_id', 'albumId')
        ?? valueOf(base, 'album_id', 'albumId');
    const albumName = String(
        valueOf(albumInfo, 'album_name', 'albumName', 'name')
        ?? valueOf(base, 'album_name', 'albumName')
        ?? song.album.name,
    );
    const albumRef = catalogRef('album', albumId);
    const resolvedArtists = normalizeArtists(metadata);
    const artists = resolvedArtists.length > 0 ? resolvedArtists : song.artists;
    const coverUrl = coverOf(albumInfo) || song.album.coverUrl;
    const resolvedAlbumId = albumId ?? song.album.id;

    return {
        ...song,
        artists,
        album: {
            ...song.album,
            id: resolvedAlbumId,
            name: albumName,
            coverUrl,
            ...(albumRef ? { catalogRef: albumRef } : {}),
        },
    };
};

const normalizeUser = (raw: any): ProviderUser => {
    const data = dataOf(raw);
    const profile = data?.user_info ?? data?.userinfo ?? data?.profile ?? data;
    return {
        id: valueOf(profile, 'userid', 'user_id', 'id', 'uid')
            ?? readProviderSessionValue('kugou', 'userid')
            ?? '',
        nickname: String(valueOf(profile, 'nickname', 'nick_name', 'username', 'name') || ''),
        avatarUrl: coverOf(profile) || valueOf(profile, 'avatar', 'pic'),
        backgroundUrl: valueOf(profile, 'background', 'backgroundUrl', 'bg_pic'),
        vipType: Number(valueOf(profile, 'vip_type', 'vipType', 'is_vip') || 0),
    };
};

// Maps the dedicated VIP response, including active product entries used by concept accounts.
const normalizeKugouVipType = (raw: any): number => {
    const data = dataOf(raw);
    const directVipType = Number(valueOf(data, 'vip_type', 'vipType', 'is_vip') || 0);
    if (directVipType > 0) return directVipType;

    const businessVips = Array.isArray(data?.busi_vip) ? data.busi_vip : [];
    return businessVips.some((entry: any) => Number(valueOf(entry, 'is_vip', 'vip_type') || 0) > 0) ? 1 : 0;
};

// Formats the claim date in KuGou's China-based calendar instead of the device's local timezone.
const getKugouReceiveDay = (date = new Date()): string => {
    const parts = new Intl.DateTimeFormat('en-US', {
        timeZone: 'Asia/Shanghai',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
    }).formatToParts(date);
    const value = (type: Intl.DateTimeFormatPartTypes) => parts.find(part => part.type === type)?.value || '';
    return `${value('year')}-${value('month')}-${value('day')}`;
};

const isSuccessfulKugouVipMutation = (raw: any): boolean => {
    const data = dataOf(raw);
    const errCode = Number(valueOf(raw, 'errcode', 'error_code') ?? valueOf(data, 'errcode', 'error_code') ?? 0);
    const rawStatus = valueOf(raw, 'status') ?? valueOf(data, 'status');
    const status = rawStatus === undefined ? 1 : Number(rawStatus);
    return errCode === 0 && status === 1;
};

const ensureKugouYouthVip = async (userId?: string): Promise<boolean> => {
    try {
        const token = readProviderSessionValue('kugou', 'token');
        const params = {
            ...(userId ? { userid: userId } : {}),
            ...(token ? { token } : {}),
        };
        const unionResponse: any = await requestKugou('youth_union_vip', params);
        const unionData = dataOf(unionResponse);
        const errCode = Number(valueOf(unionResponse, 'errcode', 'error_code') ?? valueOf(unionData, 'errcode', 'error_code') ?? 0);

        if (errCode !== 0 || !unionData || typeof unionData !== 'object') {
            console.warn('[KugouProvider] youth-union-vip:api-error', { errCode });
            return false;
        }

        const isUnionVip = normalizeKugouVipType(unionResponse) > 0;
        if (!isUnionVip) {
            console.info('[KugouProvider] youth-union-vip:not-vip, requesting youth_day_vip');
            const claimResponse = await requestKugou('youth_day_vip', {
                ...params,
                receive_day: getKugouReceiveDay(),
            });
            if (!isSuccessfulKugouVipMutation(claimResponse)) {
                console.warn('[KugouProvider] youth-day-vip:api-error', {
                    status: valueOf(claimResponse, 'status') ?? valueOf(dataOf(claimResponse), 'status'),
                    errCode: valueOf(claimResponse, 'errcode', 'error_code')
                        ?? valueOf(dataOf(claimResponse), 'errcode', 'error_code'),
                });
                return false;
            }

            const upgradeResponse = await requestKugou('youth_day_vip_upgrade', params);
            if (!isSuccessfulKugouVipMutation(upgradeResponse)) {
                console.warn('[KugouProvider] youth-day-vip-upgrade:api-error', {
                    status: valueOf(upgradeResponse, 'status') ?? valueOf(dataOf(upgradeResponse), 'status'),
                    errCode: valueOf(upgradeResponse, 'errcode', 'error_code')
                        ?? valueOf(dataOf(upgradeResponse), 'errcode', 'error_code'),
                });
                return false;
            }
            return true;
        }
        console.info('[KugouProvider] youth-union-vip:already-vip, skipping youth_day_vip');
    } catch (error) {
        // Runs while the account is read after a sign-in: the error is logged whole.
        console.warn('[KugouProvider] youth-vip-check:failed', error);
    }
    return false;
};

const normalizeCollection = (raw: any, type = 'playlist', owned = false): ProviderCollection => {
    const id = type === 'playlist'
        ? valueOf(raw, 'global_collection_id', 'globalCollectionId', 'specialid', 'specialId', 'id')
        : type === 'album'
            ? valueOf(raw, 'album_id', 'AlbumID', 'albumId', 'musiclib_id', 'musicLibId', 'list_create_listid')
            : type === 'artist'
                ? valueOf(raw, 'author_id', 'authorId')
                : undefined;
    const artists = normalizeArtists(raw);
    const aliases = valueOf(raw, 'aliases', 'alias');
    const publishedAt = normalizeTimestamp(valueOf(raw, 'publish_time', 'publishTime', 'release_date', 'releaseDate', 'year'));
    const updatedAt = normalizeTimestamp(valueOf(raw, 'update_time', 'updateTime'));
    const tracksUpdatedAt = normalizeTimestamp(valueOf(raw, 'track_update_time', 'trackUpdateTime', 'list_ver', 'listVer'));
    const playCount = Number(valueOf(raw, 'play_count', 'playCount'));
    const description = valueOf(raw, 'intro', 'description', 'brief_desc', 'briefDesc', 'brief_description', 'desc');
    const trackCountValue = valueOf(raw, 'song_count', 'count', 'm_count', 'total', 'music_num');
    const trackCount = trackCountValue === undefined ? undefined : Number(trackCountValue);

    return {
        providerId: 'kugou',
        id: id ?? '',
        name: String(valueOf(raw, 'name', 'listname', 'specialname', 'album_name', 'author_name') || ''),
        type,
        coverUrl: coverOf(raw),
        description: description === undefined || description === null ? undefined : String(description),
        ...(Number.isFinite(trackCount) ? { trackCount } : {}),
        ...(owned ? { isOwned: true } : {}),
        ...(type === 'artist' ? { albumCount: Number(valueOf(raw, 'album_count', 'albumCount') || 0) } : {}),
        ...(artists.length > 0 ? { artists } : {}),
        ...(Array.isArray(aliases) && aliases.length > 0 ? { aliases: aliases.map(String).filter(Boolean) } : {}),
        ...(publishedAt !== undefined ? { publishedAt } : {}),
        ...(typeof valueOf(raw, 'company', 'publisher') === 'string' && valueOf(raw, 'company', 'publisher')
            ? { publisher: String(valueOf(raw, 'company', 'publisher')) }
            : {}),
        ...(Number.isFinite(playCount) && playCount >= 0 ? { playCount } : {}),
        ...(updatedAt !== undefined ? { updatedAt } : {}),
        ...(tracksUpdatedAt !== undefined ? { tracksUpdatedAt } : {}),
        ...(Boolean(valueOf(raw, 'is_liked', 'isLiked')) ? { isLiked: true } : {}),
        providerData: jsonData([
            ['listId', valueOf(raw, 'listid', 'list_id')],
            ['globalCollectionId', valueOf(raw, 'global_collection_id')],
            ['specialId', valueOf(raw, 'specialid')],
            ['owned', owned],
            ['creatorUserId', valueOf(raw, 'create_userid', 'list_create_userid', 'userid')],
            ['creatorListId', valueOf(raw, 'create_listid', 'list_create_listid', 'listid')],
            ['creatorGid', valueOf(raw, 'gid', 'list_create_gid', 'global_collection_id')],
            ['musicSize', type === 'artist' ? valueOf(raw, 'song_count', 'music_num') : undefined],
            ['albumSize', type === 'artist' ? valueOf(raw, 'album_count') : undefined],
        ]),
    };
};

type KugouUserCollectionType = 'playlist' | 'album';

// Distinguishes KuGou's mixed user-library response before normalizing collection ids.
const getKugouUserCollectionType = (raw: any): KugouUserCollectionType => {
    const source = Number(valueOf(raw, 'source'));
    return source === 2 || valueOf(raw, 'musiclib_id', 'musicLibId') !== undefined
        ? 'album'
        : 'playlist';
};

const isKugouOwnedPlaylist = (raw: any): boolean => {
    const type = valueOf(raw, 'type');
    return type === undefined || type === null || Number(type) === 0;
};

// Restricts the player-panel destination list to KuGou playlists that accept user track mutations.
const canAddToKugouPlaylist = (playlist: ProviderCollection): boolean => {
    if (playlist.type !== 'playlist' || playlist.isOwned !== true) return false;

    const listId = String(playlist.providerData?.listId || '');
    const name = playlist.name.trim();
    return listId !== '2' && name !== '我喜欢' && name !== '我喜欢的音乐';
};

// Advances mixed user-library pagination with the raw response count, not the filtered item count.
const pageOfWithRawItemCount = <T>(
    items: T[],
    response: any,
    limit: number,
    offset: number,
    rawItemCount: number,
): ProviderPage<T> => {
    const data = dataOf(response);
    const totalCandidate = [data?.total, data?.list_count, data?.total_count, data?.count]
        .map(value => Number(value))
        .find(value => Number.isFinite(value) && value >= 0);
    const nextOffset = offset + rawItemCount;
    return {
        items,
        ...(totalCandidate !== undefined ? { total: totalCandidate } : {}),
        hasMore: totalCandidate !== undefined ? nextOffset < totalCandidate : rawItemCount === limit,
        nextOffset,
    };
};

const pageOf = <T>(items: T[], raw: any, limit: number, offset: number): ProviderPage<T> => {
    const data = dataOf(raw);
    const total = Number(data?.total ?? raw?.total ?? data?.total_count ?? raw?.total_count ?? data?.count ?? items.length);
    return { items, total, hasMore: offset + items.length < total || items.length === limit, nextOffset: offset + items.length };
};

// Keeps one result per provider-aware playback identity while preserving search ranking order.
const normalizeKugouSearchSongs = (rawItems: any[]): UnifiedSong[] => {
    const seenSongKeys = new Set<string>();
    return rawItems
        .map(normalizeKugouSong)
        .filter(song => {
            if (!song.id) return false;
            const songKey = getPlaybackSongKey(song);
            if (seenSongKeys.has(songKey)) return false;
            seenSongKeys.add(songKey);
            return true;
        });
};

const qualityValue = (quality: AudioQualityPreference): string => ({
    standard: '128', high: '320', ultra: '320', lossless: 'flac', hires: 'high',
})[quality];

const QUALITY_FALLBACKS: Record<AudioQualityPreference, AudioQualityPreference[]> = {
    standard: ['standard'],
    high: ['high', 'standard'],
    // For the type: KuGou is never asked at 'ultra' (omni asks at 'high' in its place).
    ultra: ['high', 'standard'],
    lossless: ['lossless', 'high', 'standard'],
    hires: ['hires', 'lossless', 'high', 'standard'],
};

const qualityFallbacks = (quality: AudioQualityPreference): AudioQualityPreference[] => QUALITY_FALLBACKS[quality];

const getId = (value: MediaId | ProviderCollection | SongResult) => typeof value === 'object' ? value.id : value;

const getKugouUserId = (): string => String(readProviderSessionValue('kugou', 'userid') || '');

const kugouChorusRangesCache = new Map<string, Promise<ChorusRange[]>>();

// Converts KuGou's millisecond climax payload into the shared second-based range model.
const parseKugouChorusRanges = (response: unknown): ChorusRange[] => {
    const ranges = (response as any)?.data;
    if (!Array.isArray(ranges)) return [];

    return ranges
        .map((range: any) => ({
            startTime: Number(range?.start_time) / 1000,
            endTime: Number(range?.end_time) / 1000,
        }))
        .filter(range => Number.isFinite(range.startTime) && Number.isFinite(range.endTime) && range.endTime > range.startTime);
};

const getKugouChorusRanges = async (songId: MediaId): Promise<ChorusRange[]> => {
    const hash = String(songId).trim().toUpperCase();
    if (!hash) return [];

    const cached = kugouChorusRangesCache.get(hash);
    if (cached) return cached;

    const request = requestKugou('song_climax', { hash })
        .then(parseKugouChorusRanges)
        .catch(error => {
            console.warn(`[KugouProvider] Failed to fetch chorus ranges for song ${hash}:`, error);
            return [];
        });
    kugouChorusRangesCache.set(hash, request);
    return request;
};

const getKugouLyricCandidate = async (song: SongResult): Promise<any | null> => {
    const sourceRef = song.sourceRef?.kind === 'online' && song.sourceRef.providerId === 'kugou'
        ? song.sourceRef
        : null;
    const albumAudioId = sourceRef?.providerData?.albumAudioId
        ?? sourceRef?.providerData?.mixSongId
        ?? sourceRef?.providerData?.catalogLookupId;
    const response = await requestKugou('search_lyric', {
        hash: String(song.kgHash ?? song.id).toUpperCase(),
        duration: song.durationMs,
        man: 'no',
        ...(albumAudioId !== undefined ? { album_audio_id: String(albumAudioId) } : {}),
    });
    const candidates = (response as any)?.candidates;
    return Array.isArray(candidates) ? candidates[0] ?? null : null;
};

// Fetches the server-decoded KRC payload exposed by the current KuGou provider API.
const getKugouLyrics = async (song: SongResult) => {
    const candidate = await getKugouLyricCandidate(song);
    if (!candidate?.id || !candidate?.accesskey) {
        return { lyrics: null, isPureMusic: false, chorusRanges: [] };
    }

    const response = await requestKugou('lyric', {
        id: String(candidate.id),
        accesskey: String(candidate.accesskey),
        fmt: 'krc',
        decode: true,
    });
    const lyricText = typeof (response as any)?.decodeContent === 'string'
        ? (response as any).decodeContent
        : '';
    if (isPureMusicLyricText(lyricText)) {
        return { lyrics: null, mainText: lyricText, wordByWordText: lyricText, isPureMusic: true, chorusRanges: [] };
    }
    const parsed = lyricText ? parseLyricsByFormat('krc', lyricText, '') : null;
    if (!hasRenderableLyrics(parsed)) {
        return { lyrics: null, mainText: lyricText || null, wordByWordText: lyricText || null, isPureMusic: false, chorusRanges: [] };
    }
    parsed.isWordByWord = true;
    const songId = song.kgHash ?? song.id;
    return {
        lyrics: parsed,
        mainText: lyricText,
        wordByWordText: lyricText,
        isPureMusic: false,
        chorusRanges: await getKugouChorusRanges(songId),
    };
};

const getKugouUserPlaylistItems = async (userId: MediaId): Promise<any[]> => {
    const response = await requestKugou('user_playlist', {
        userid: String(userId),
        page: 1,
        pagesize: 100,
    });
    return listOf(response);
};

// Loads the raw album metadata needed by KuGou's playlist-based album subscription endpoint.
const getKugouAlbumDetailRaw = async (id: MediaId): Promise<any | null> => {
    const response = await requestKugou('album_detail', { id: String(id) });
    const data = dataOf(response);
    const rawAlbum = listOf(response)[0] ?? data?.album ?? data;
    return rawAlbum && typeof rawAlbum === 'object' && !Array.isArray(rawAlbum) ? rawAlbum : null;
};

// Identifies KuGou's built-in "我喜欢" playlist, which is the provider's song-like collection.
const isKugouLikedPlaylist = (raw: any): boolean => {
    if (getKugouUserCollectionType(raw) !== 'playlist') return false;
    const name = String(valueOf(raw, 'name', 'listname') || '').trim();
    return name === '我喜欢' || name === '我喜欢的音乐' || valueOf(raw, 'listid', 'list_id') === 2;
};

type KugouLikedPlaylistRef = { listId: MediaId; globalCollectionId?: MediaId };

const kugouLikedPlaylistRefCache = new Map<string, KugouLikedPlaylistRef>();

let lastSeenKugouUserId: string | null = null;

// The row (`fileid`) each liked song has in the liked playlist, by track hash, as the last read of
// the account's liked songs brought it. An unlike sends the row, and looks it up in the list where
// none is noted (see likeSong). A song's row goes as soon as a like or an unlike is sent for it,
// taken or not: a like gives no new row, an unlike ends the old one, and after a failure the row
// may be gone. Rows are not kept across sessions: an old row would take another song out.
const kugouLikedRowIds = new Map<string, MediaId>();
// When a like or an unlike was last sent for a song, by track hash. A read of the liked songs
// begun before that may show the song's row as it was, and notes none for it.
const kugouLikedRowsSentAt = new Map<string, number>();
let kugouLikedRowReads = 0;

// 登出、切号和会话失效都要清：歌单引用和行号都只对写下它们的那个账号有效。
const clearKugouLikedCaches = (): void => {
    kugouLikedPlaylistRefCache.clear();
    kugouLikedTrackCache.clear();
    kugouLikedRowIds.clear();
    kugouLikedRowsSentAt.clear();
};

// Notes the rows a read of the liked songs brought; the rows of songs it does not show go.
const noteKugouLikedRows = (songs: UnifiedSong[], readBeganAt: number): void => {
    kugouLikedRowIds.clear();
    for (const song of songs) {
        const fileId = song.sourceRef?.kind === 'online' ? song.sourceRef.providerData?.fileId : undefined;
        if ((typeof fileId !== 'string' && typeof fileId !== 'number') || String(fileId) === '') continue;
        const hash = getKugouTrackHash(song);
        if ((kugouLikedRowsSentAt.get(hash) ?? Number.NEGATIVE_INFINITY) >= readBeganAt) continue;
        kugouLikedRowIds.set(hash, fileId);
    }
};

// 收藏相关入口在动缓存之前先对一次账号，换号就把上一个账号的引用和行号丢掉。
const syncKugouSessionUser = (): void => {
    const userId = getKugouUserId();
    if (lastSeenKugouUserId === userId) return;
    lastSeenKugouUserId = userId;
    clearKugouLikedCaches();
};

// 只缓存完整的引用：缺 global_collection_id 的残缺状态会一直粘到登出，取消收藏从此必失败。
const rememberKugouLikedPlaylistRef = (userId: MediaId, ref: KugouLikedPlaylistRef): void => {
    if (!ref.globalCollectionId) return;
    kugouLikedPlaylistRefCache.set(String(userId), ref);
};

// Finds KuGou's built-in "我喜欢" playlist, which is the provider's song-like collection.
const getKugouLikedPlaylist = async (userId: MediaId): Promise<any | null> => {
    const items = await getKugouUserPlaylistItems(userId);
    return items.find(isKugouLikedPlaylist) ?? null;
};

// 解析失败一律抛错：返回空数组会被上层写成"这个账号一首收藏都没有"，连快照一起清掉。
const getKugouLikedPlaylistTracks = async (userId: MediaId): Promise<UnifiedSong[]> => {
    syncKugouSessionUser();
    const playlist = await getKugouLikedPlaylist(userId);
    const listId = valueOf(playlist, 'listid', 'list_id');
    const globalCollectionId = valueOf(playlist, 'global_collection_id', 'globalCollectionId');
    if (listId === undefined || listId === null || !globalCollectionId) {
        throw new OnlineProviderError(
            'invalid-response',
            'KuGou liked playlist could not be resolved',
            'kugou',
        );
    }
    rememberKugouLikedPlaylistRef(userId, { listId, globalCollectionId });
    // 账号的收藏要读平台此刻的：10 秒内的那份缓存是给取消收藏找行号用的，里面没有别处刚做的改动。
    return getKugouPlaylistTrackSongs(String(globalCollectionId), { forceRefresh: true });
};

// Uses the newest song's observed cover when KuGou leaves a user playlist cover empty.
const getKugouPlaylistFallbackCover = async (rawPlaylist: any): Promise<string | undefined> => {
    const globalCollectionId = valueOf(rawPlaylist, 'global_collection_id', 'globalCollectionId');
    if (globalCollectionId === undefined || globalCollectionId === null) return undefined;

    const response = await requestKugou('playlist_track_all', {
        id: String(globalCollectionId),
        page: 1,
        pagesize: 1,
    });
    return listOf(response)
        .map(normalizeKugouSong)
        .map(song => song.album.coverUrl)
        .find((cover): cover is string => Boolean(cover));
};

const getKugouTrackHash = (track: MediaId | SongResult): string => {
    if (typeof track !== 'object') return String(track).toUpperCase();
    const sourceData = track.sourceRef?.kind === 'online' ? track.sourceRef.providerData : undefined;
    return String(sourceData?.hash || track.kgHash || track.id).toUpperCase();
};

const getKugouTrackAddData = (track: MediaId | SongResult): string => {
    if (typeof track !== 'object') return `|${String(track).toUpperCase()}|0|0`;
    const sourceData = track.sourceRef?.kind === 'online' ? track.sourceRef.providerData : undefined;
    return [
        track.name,
        getKugouTrackHash(track),
        String(sourceData?.albumId || track.album?.id || 0),
        String(sourceData?.mixSongId || 0),
    ].join('|');
};

const getKugouTrackFileId = (track: MediaId | SongResult): string => {
    if (typeof track !== 'object') return String(track);
    const sourceData = track.sourceRef?.kind === 'online' ? track.sourceRef.providerData : undefined;
    return String(sourceData?.fileId || track.id);
};

// 20000 首是保护上限，不是业务上限：到顶还有下一页就报错，不能把截断结果当成完整收藏列表存下去。
const KUGOU_LIKED_TRACK_MAX_PAGES = 200;
const KUGOU_LIKED_TRACK_CACHE_TTL_MS = 10_000;
const kugouLikedTrackCache = new Map<string, { fetchedAt: number; songs: UnifiedSong[] }>();

// KuGou's playlist entry `fileid` is local to one playlist, unlike the global audio hash. The
// liked-song mutations must therefore look up the row id inside the liked playlist itself.
const getKugouPlaylistTrackSongs = async (
    globalCollectionId: string,
    options: { forceRefresh?: boolean } = {},
): Promise<UnifiedSong[]> => {
    const cached = kugouLikedTrackCache.get(globalCollectionId);
    if (!options.forceRefresh && cached && Date.now() - cached.fetchedAt < KUGOU_LIKED_TRACK_CACHE_TTL_MS) {
        return cached.songs;
    }

    const songs: UnifiedSong[] = [];
    let completed = false;
    for (let page = 1; page <= KUGOU_LIKED_TRACK_MAX_PAGES; page += 1) {
        const response = await requestKugou('playlist_track_all', {
            id: globalCollectionId,
            page,
            pagesize: KUGOU_MAX_PAGE_SIZE,
        });
        const rawItems = listOf(response);
        songs.push(...rawItems.map(normalizeKugouSong));
        // 字段顺序和 pageOf 保持一致。只有明显大于一页时才当总数用：有的响应里 count 是本页条数，
        // 拿它当总数会在第一页就判定读完，又变回只读 100 首的老问题。
        const total = Number(valueOf(dataOf(response), 'total', 'total_count', 'count') ?? Number.NaN);
        const countsWholeList = Number.isFinite(total) && total > KUGOU_MAX_PAGE_SIZE;
        if (rawItems.length === 0 || rawItems.length < KUGOU_MAX_PAGE_SIZE) {
            // 短页当作末尾。读到的比响应自己报的总数少时记一行：没有抓到过这种响应，
            // 真实账号的日志才能说明是列表里有读不出来的歌，还是中途断了。
            if (countsWholeList && songs.length < total) {
                console.warn(`[KuGou] A playlist ended on a short page: ${songs.length} songs read, its answer counts ${total}`);
            }
            completed = true;
            break;
        }
        if (countsWholeList && songs.length >= total) {
            completed = true;
            break;
        }
    }

    if (!completed) {
        throw new OnlineProviderError(
            'invalid-response',
            `KuGou playlist ${globalCollectionId} exceeded ${KUGOU_LIKED_TRACK_MAX_PAGES} pages`,
            'kugou',
        );
    }

    kugouLikedTrackCache.set(globalCollectionId, { fetchedAt: Date.now(), songs });
    return songs;
};

const removeKugouPlaylistTrackCacheEntry = (globalCollectionId: string, hash: string): void => {
    const cached = kugouLikedTrackCache.get(globalCollectionId);
    if (!cached) return;
    kugouLikedTrackCache.set(globalCollectionId, {
        // 保留原时间戳：每删一首就续命 10 秒的话，连续操作能让这份缓存永不过期。
        fetchedAt: cached.fetchedAt,
        songs: cached.songs.filter(song => getKugouTrackHash(song) !== hash),
    });
};

const kugouHistoryNameByDate = new Map<string, string>();

const normalizeKugouHistoryEntries = (response: any): ProviderHistoryEntry[] => {
    const entries = listOf(response).map((item: any) => ({
        id: String(valueOf(item, 'date', 'history_name', 'id') || ''),
        label: String(valueOf(item, 'history_name', 'date', 'name') || ''),
        providerData: jsonData([['date', valueOf(item, 'date')], ['historyName', valueOf(item, 'history_name')]]),
    }));

    entries.forEach(entry => {
        const date = String(entry.providerData?.date || entry.id);
        const historyName = String(entry.providerData?.historyName || entry.label);
        if (date && historyName) kugouHistoryNameByDate.set(date, historyName);
    });
    return entries;
};

// Resolves the provider's internal history name when the Omni caller only has a display date.
const getKugouHistoryName = async (date: string): Promise<string> => {
    const cached = kugouHistoryNameByDate.get(date);
    if (cached) return cached;

    const response = await requestKugou('everyday_history', { mode: 'list' });
    normalizeKugouHistoryEntries(response);
    return kugouHistoryNameByDate.get(date) || date;
};

export const kugouProvider: OnlineMusicProvider = {
    id: 'kugou',
    displayName: 'KuGou Music',
    shortName: '酷狗',
    mark: { letter: 'K', color: '#2563eb' },
    getAvailability: getKugouTransportAvailability,
    describeFailure: describeKugouFailure,
    capabilities: {
        search: true, playback: true, lyrics: true, auth: true, userLibrary: true,
        playlists: true, albums: true, artists: true, recommendations: true, mutations: true,
        wordByWordLyrics: true, userCloud: true, historyRecommendations: true,
        playlistSubscription: true, playlistTrackMutations: true, likes: true, userAlbums: true,
    },
    normalizeSong: normalizeKugouSong,
    normalizeUser,
    normalizeCollection,
    songMetadata: {
        getSongMetadata(song) {
            return createProviderSongMetadata(song);
        },
    },
    search: {
        async searchSongs(query, limit, offset) {
            const page = Math.floor(offset / limit) + 1;
            if (!hasKugouAuthenticatedSearchSession()) {
                const response = await requestKugouAnonymousSearch(
                    buildKugouLyricSearchQuery(query),
                    page,
                    limit,
                );
                const rawItems = listOf(response);
                return pageOfWithRawItemCount(
                    normalizeKugouSearchSongs(rawItems),
                    response,
                    limit,
                    offset,
                    rawItems.length,
                );
            }
            const response = await requestKugou('search', { keywords: query, keyword: query, type: 'song', page, pagesize: limit });
            const rawItems = listOf(response);
            return pageOfWithRawItemCount(
                normalizeKugouSearchSongs(rawItems),
                response,
                limit,
                offset,
                rawItems.length,
            );
        },
    },
    playback: {
        async getSongDetail(id) {
            const response = await requestKugou('audio', { hash: String(id) });
            const item = listOf(response)[0] ?? dataOf(response);
            return hashOf(item) ? normalizeKugouSong(item) : null;
        },
        async getAudioSource(song, quality) {
            const sourceRef = song.sourceRef?.kind === 'online' ? song.sourceRef : null;
            const hash = String(sourceRef?.providerData?.hash || sourceRef?.mediaId || song.kgHash || song.id).toUpperCase();
            const qualities = sourceRef?.variant === 'cloud' ? [quality] : qualityFallbacks(quality);
            const albumId = String(sourceRef?.providerData?.albumId || '');
            const albumAudioId = String(sourceRef?.providerData?.albumAudioId || '');
            // What is said when no URL comes: the last /song/url answer without one (it carries KuGou's error
            // code), else the legacy endpoint's, else the first request that failed.
            let noUrlSeen: { status?: unknown; errorCode?: unknown } | undefined;
            let firstFailure: unknown;
            // A request that ran out of time stops the remaining /song/url qualities and variants: they would wait
            // as long. The legacy endpoint is still asked once.
            let songUrlChainStopped = false;

            // Tries the preferred KuGou quality first and degrades until a playable URL is returned.
            for (const candidateQuality of qualities) {
                if (songUrlChainStopped) break;
                const requestVariants = sourceRef?.variant === 'cloud'
                    ? [{ name: 'cloud', operation: 'user_cloud_url' as const, params: {
                        hash, id: String(sourceRef.providerData?.fileId || ''),
                    } }]
                    : [
                        { name: 'metadata', operation: 'song_url' as const, params: {
                            hash,
                            quality: qualityValue(candidateQuality),
                            album_id: albumId,
                            album_audio_id: albumAudioId,
                        } },
                        ...((albumId || albumAudioId) ? [{ name: 'hash-only', operation: 'song_url' as const, params: {
                            hash,
                            quality: qualityValue(candidateQuality),
                            album_id: '',
                            album_audio_id: '',
                        } }] : []),
                    ];

                // Search metadata can contain album IDs that do not belong to the returned hash, so retry the same quality by hash alone first.
                for (const requestVariant of requestVariants) {
                    try {
                        const response = await requestKugou(requestVariant.operation, requestVariant.params);
                        const data = dataOf(response);
                        const payload = Array.isArray(data) ? data[0] : data;
                        const url = audioUrlOf(
                            valueOf(payload, 'play_url', 'playUrl', 'url')
                            ?? valueOf(data?.[0], 'url', 'play_url'),
                        );
                        if (url) {
                            const trackGain = toFiniteNumber(valueOf(payload, 'volume'));
                            const trackPeak = decibelsToLinearPeak(valueOf(payload, 'volume_peak'));
                            const replayGain = trackGain === undefined && trackPeak === undefined
                                ? undefined
                                : {
                                    ...(trackGain === undefined ? {} : { trackGain }),
                                    ...(trackPeak === undefined ? {} : { trackPeak }),
                                };
                            console.info('[KuGouProvider] playback:url-resolved', {
                                hash,
                                requestedQuality: quality,
                                resolvedQuality: candidateQuality,
                                requestVariant: requestVariant.name,
                            });
                            return {
                                // Preserve the upstream candidate here; the shared playback transport normalizes its scheme.
                                url,
                                fetchedAt: Date.now(),
                                quality: candidateQuality,
                                ...(replayGain ? { replayGain } : {}),
                            };
                        }
                        noUrlSeen = {
                            status: valueOf(data, 'status') ?? valueOf(response, 'status'),
                            errorCode: valueOf(data, 'errcode', 'error_code') ?? valueOf(response, 'errcode', 'error_code'),
                        };
                        console.warn('[KuGouProvider] playback:no-url', {
                            hash,
                            requestedQuality: quality,
                            candidateQuality,
                            requestVariant: requestVariant.name,
                            ...noUrlSeen,
                        });
                    } catch (error) {
                        // A sign-in that has ended is said at once: another quality would be refused the same way.
                        if (error instanceof OnlineProviderError && error.code === 'auth-required') throw error;
                        firstFailure ??= error;
                        console.warn('[KuGouProvider] playback:quality-failed', {
                            hash,
                            requestedQuality: quality,
                            candidateQuality,
                            requestVariant: requestVariant.name,
                            ...errorFields(error),
                        });
                        // Asked to wait, or nowhere to ask (the local service is not loaded, the web build has no
                        // address): every other request would be answered the same, the legacy one too.
                        const said = describeKugouFailure('audio', error);
                        if (said?.case === 'local-service-stopped' || said?.case === 'not-configured'
                            || said?.httpStatus === 429 || (error instanceof OnlineProviderError && error.retryAfterMs !== undefined)) throw error;
                        if (isKugouTimeout(error)) {
                            songUrlChainStopped = true;
                            break;
                        }
                    }
                }
            }

            // KuGou's current /song/url can mark certain hashes as unavailable (status: 3)
            // even though the same hash is still playable through the old mobile endpoint.
            // Only use this as a last resort after every quality and hash variant above has failed.
            if (sourceRef?.variant !== 'cloud') {
                try {
                    const legacyResponse = await requestKugouLegacyPlayInfo(hash);
                    const legacyUrl = audioUrlOf(valueOf(legacyResponse, 'url') ?? valueOf(dataOf(legacyResponse), 'url'))
                        ?? audioUrlOf(valueOf(legacyResponse, 'backup_url') ?? valueOf(dataOf(legacyResponse), 'backup_url'));
                    if (legacyUrl) {
                        console.info('[KuGouProvider] playback:url-resolved-legacy', {
                            hash,
                            requestedQuality: quality,
                        });
                        return {
                            url: legacyUrl,
                            fetchedAt: Date.now(),
                            quality: 'standard',
                        };
                    }
                    const legacyStatus = valueOf(legacyResponse, 'status') ?? valueOf(dataOf(legacyResponse), 'status');
                    noUrlSeen ??= { status: legacyStatus };
                    console.warn('[KuGouProvider] playback:no-url-legacy', {
                        hash,
                        requestedQuality: quality,
                        status: legacyStatus,
                    });
                } catch (error) {
                    firstFailure ??= error;
                    console.warn('[KuGouProvider] playback:legacy-failed', {
                        hash,
                        requestedQuality: quality,
                        ...errorFields(error),
                    });
                }
            }

            console.warn('[KuGouProvider] playback:unavailable', { hash, requestedQuality: quality, attemptedQualities: qualities });
            if (noUrlSeen || firstFailure === undefined) throw kugouNoUrlError(noUrlSeen, !hasKugouAuthenticatedSearchSession());
            throw firstFailure;
        },
    },
    lyrics: {
        getLyrics: getKugouLyrics,
        getChorusRanges: getKugouChorusRanges,
    },
    auth: {
        getLoginTexts: () => ({ title: 'home.loginTitleKugou', note: 'home.loginNoteKugou' }),
        async getLoginStatus() {
            const userId = readProviderSessionValue('kugou', 'userid');
            const hasElectronTransport = typeof window !== 'undefined' && Boolean(window.electron?.kugouRequest);
            console.info('[KugouProvider] login-status:start', {
                transport: hasElectronTransport ? 'electron' : 'web',
                hasWebUserId: Boolean(userId),
            });
            if (!userId && !hasElectronTransport) return null;
            try {
                const response = await requestKugou('user_detail', { userid: userId || undefined });
                let user = normalizeUser(response);
                if (user.id && user.nickname) {
                    try {
                        const claimedYouthVip = await ensureKugouYouthVip(String(user.id));
                        const vipResponse = await requestKugou('user_vip_detail', { userid: String(user.id) });
                        user = { ...user, vipType: normalizeKugouVipType(vipResponse) };
                        if (claimedYouthVip && user.vipType === 0) {
                            user = { ...user, vipType: 1 };
                        }
                    } catch (error) {
                        console.warn('[KugouProvider] login-status:vip-error', error);
                    }
                }
                const responseKeys = Object.keys(dataOf(response) || {});
                console.info('[KugouProvider] login-status:profile', {
                    responseKeys: responseKeys.slice(0, 20),
                    responseKeyCount: responseKeys.length,
                    hasUserId: Boolean(user.id),
                    hasNickname: Boolean(user.nickname),
                    hasAvatar: Boolean(user.avatarUrl),
                });
                return user.id && user.nickname ? user : null;
            } catch (error) {
                console.warn('[KugouProvider] login-status:error', error);
                throw error;
            }
        },
        // The request takes the session as it is when it is made (`requestKugou`); the session and
        // what was read with it go at once, before the first wait and whatever KuGou answers.
        async logout() {
            const told = requestKugou('logout').catch(() => undefined);
            ['cookie', 'token', 'userid', 'dfid'].forEach(key => removeProviderSessionValue('kugou', key));
            clearKugouLikedCaches();
            lastSeenKugouUserId = null;
            await told;
        },
        // The session KuGou no longer takes goes the same way as at a sign-out.
        signInRanOut: () => kugouProvider.auth!.logout(),
        showsKeptAccountAtStart: true,
        async startLogin() {
            const response = await requestKugou('login_qr_key');
            const data = dataOf(response);
            return String(valueOf(data, 'qrcode', 'qrkey', 'key', 'ticket') || '');
        },
        async createQr(key) {
            const response = await requestKugou('login_qr_create', { key, qrimg: true });
            const data = dataOf(response);
            return String(valueOf(data, 'base64', 'qrimg', 'qrcode', 'url') || '');
        },
        async checkLogin(key) {
            const response = await requestKugou('login_qr_check', { key, qrcode: key });
            const data = dataOf(response);
            const status = Number(valueOf(data, 'status', 'code') ?? valueOf(response, 'status', 'code'));
            if (status === 0) return { state: 'expired' };
            if (status === 1) return { state: 'waiting' };
            if (status === 2 || status === 3) return { state: 'scanned' };
            if (status === 4 || data?.token) return { state: 'confirmed' };
            const message = String(valueOf(data, 'message', 'msg', 'error') || '');
            return { state: 'error', message, failure: kugouCheckFailure(status, message) };
        },
        describeLoginFailure: describeKugouLoginFailure,
    },
    library: {
        async getUserPlaylists(userId, limit, offset) {
            const requestLimit = Math.min(Math.max(1, limit), KUGOU_MAX_PAGE_SIZE);
            const response = await requestKugou('user_playlist', { userid: String(userId), page: Math.floor(offset / requestLimit) + 1, pagesize: requestLimit });
            const rawItems = listOf(response);
            const playlistItems = rawItems
                .filter(item => getKugouUserCollectionType(item) === 'playlist')
                .map(item => ({ raw: item, collection: normalizeCollection(item, 'playlist', isKugouOwnedPlaylist(item)) }))
                .filter(({ collection }) => collection.id !== '');
            const items = await Promise.all(playlistItems.map(async ({ raw, collection }) => {
                if (collection.coverUrl || !isKugouOwnedPlaylist(raw)) return collection;
                const fallbackCover = await getKugouPlaylistFallbackCover(raw).catch(() => undefined);
                return fallbackCover ? { ...collection, coverUrl: fallbackCover } : collection;
            }));
            return pageOfWithRawItemCount(items, response, requestLimit, offset, rawItems.length);
        },
        async getUserAlbums(userId, limit, offset) {
            const requestLimit = Math.min(Math.max(1, limit), KUGOU_MAX_PAGE_SIZE);
            const response = await requestKugou('user_playlist', { userid: String(userId), page: Math.floor(offset / requestLimit) + 1, pagesize: requestLimit });
            const rawItems = listOf(response);
            const items = rawItems
                .filter(item => getKugouUserCollectionType(item) === 'album')
                .map(item => normalizeCollection(item, 'album'))
                .filter(collection => collection.id !== '');
            return pageOfWithRawItemCount(items, response, requestLimit, offset, rawItems.length);
        },
        async getLikedSongIds(userId) {
            const order = ++kugouLikedRowReads;
            const beganAt = performance.now();
            // The liked list is read to its end or the read throws (getKugouPlaylistTrackSongs).
            const songs = await getKugouLikedPlaylistTracks(userId);
            // The rows of the newest read stand: an older one that ends after it notes none.
            if (order === kugouLikedRowReads) noteKugouLikedRows(songs, beganAt);
            return { ids: songs.map(song => song.id).filter(Boolean), whole: true };
        },
        // The count KuGou's list of the account's playlists gives for the liked list, read the way
        // a playlist card's count is: one request, the one the read above begins with. It is not
        // the count of the rows that read brings, so the two may differ.
        async getLikedSongCount(userId) {
            const playlist = await getKugouLikedPlaylist(userId);
            return playlist ? normalizeCollection(playlist).trackCount ?? null : null;
        },
        // The cloud drive stands among the collections as one entry; nothing is asked for it.
        async getCloudCollection(user) {
            return { providerId: 'kugou', id: 'cloud', name: i18n.t('ui.cloudDrive'), type: 'cloud', coverUrl: user?.avatarUrl };
        },
    },
    catalog: {
        canResolveSongCatalogRefs: song => Boolean(getKugouCatalogLookupId(song)),
        resolveSongCatalogRefs: resolveKugouSongCatalogRefs,
        async getPlaylistTracks(id, limit, offset, collection) {
            const recommendationPage = await getKugouRecommendationPage(collection, limit, offset);
            if (recommendationPage) return recommendationPage;

            const requestLimit = Math.min(Math.max(1, limit), KUGOU_MAX_PAGE_SIZE);
            const response = await requestKugou('playlist_track_all', { id: String(id), pagesize: requestLimit, page: Math.floor(offset / requestLimit) + 1 });
            return pageOf(listOf(response).map(normalizeKugouSong), response, requestLimit, offset);
        },
        async getCloudTracks(limit, offset) {
            const requestLimit = Math.min(Math.max(1, limit), KUGOU_MAX_PAGE_SIZE);
            const response = await requestKugou('user_cloud', {
                userid: getKugouUserId() || undefined,
                page: Math.floor(offset / requestLimit) + 1,
                pagesize: requestLimit,
            });
            const items = listOf(response).map(item => {
                const song = normalizeKugouSong(item);
                return { ...song, sourceRef: { ...song.sourceRef, variant: 'cloud' } };
            });
            return pageOf(items, response, requestLimit, offset);
        },
        async getPlaylistDetail(id, existingCollection) {
            if (existingCollection && isKugouVirtualRecommendation(existingCollection)) return existingCollection;

            const response = await requestKugou('playlist_detail', { ids: String(id) });
            const data = dataOf(response);
            const rawPlaylist = listOf(response)[0] ?? data?.info?.[0] ?? data;
            if (!rawPlaylist || typeof rawPlaylist !== 'object' || Array.isArray(rawPlaylist)) {
                return existingCollection || null;
            }
            const normalized = normalizeCollection({
                ...rawPlaylist,
                global_collection_id: valueOf(rawPlaylist, 'global_collection_id') ?? id,
            }, 'playlist', Boolean(existingCollection?.isOwned));
            return {
                ...normalized,
                name: normalized.name || existingCollection?.name || '',
                coverUrl: normalized.coverUrl || existingCollection?.coverUrl,
                description: normalized.description || existingCollection?.description,
                trackCount: normalized.trackCount !== undefined && normalized.trackCount > 0
                    ? normalized.trackCount
                    : existingCollection?.trackCount,
                creator: normalized.creator || existingCollection?.creator,
                providerData: { ...existingCollection?.providerData, ...normalized.providerData },
            };
        },
        async getAlbumDetail(id, existingCollection) {
            const rawAlbum = await getKugouAlbumDetailRaw(id);
            if (!rawAlbum) {
                return existingCollection || null;
            }

            const normalized = normalizeCollection({
                ...rawAlbum,
                album_id: valueOf(rawAlbum, 'album_id', 'AlbumID', 'albumId') ?? id,
            }, 'album');
            return {
                ...normalized,
                name: normalized.name || existingCollection?.name || '',
                coverUrl: normalized.coverUrl || existingCollection?.coverUrl,
                description: normalized.description || existingCollection?.description,
                trackCount: normalized.trackCount !== undefined && normalized.trackCount > 0
                    ? normalized.trackCount
                    : existingCollection?.trackCount,
                artists: normalized.artists?.length ? normalized.artists : existingCollection?.artists,
                aliases: normalized.aliases?.length ? normalized.aliases : existingCollection?.aliases,
                publishedAt: normalized.publishedAt ?? existingCollection?.publishedAt,
                publisher: normalized.publisher || existingCollection?.publisher,
            };
        },
        async getAlbumTracks(id, limit = 30, offset = 0, collection) {
            const pageSize = Math.min(Math.max(1, limit), 30);
            const response = await requestKugou('album_songs', {
                id: String(id),
                page: Math.floor(offset / pageSize) + 1,
                pagesize: pageSize,
            });
            const items = listOf(response).map(raw => {
                const song = normalizeKugouSong(raw);
                if (song.album.name || !collection?.name) return song;
                return {
                    ...song,
                    album: { ...song.album, name: collection.name },
                };
            });
            return pageOf(items, response, pageSize, offset);
        },
        async getArtistSongs(id, limit, offset) {
            const response = await requestKugou('artist_audios', { id: String(id), page: Math.floor(offset / limit) + 1, pagesize: limit });
            return pageOf(listOf(response).map(normalizeKugouSong), response, limit, offset);
        },
        async getArtistAlbums(id, limit, offset) {
            const response = await requestKugou('artist_albums', { id: String(id), page: Math.floor(offset / limit) + 1, pagesize: limit });
            const items = listOf(response)
                .map(item => normalizeCollection(item, 'album'))
                .filter(collection => collection.id !== '');
            return pageOf(items, response, limit, offset);
        },
        async getArtistDetail(id) {
            const response = await requestKugou('artist_detail', { id: String(id) });
            const data = dataOf(response);
            return data ? normalizeCollection(data, 'artist') : null;
        },
        async getSubscriptionStatus(type, id, collection) {
            if (isKugouVirtualRecommendation(collection)) return false;

            const userId = getKugouUserId();
            if (!userId) return false;
            const response = await requestKugou('user_playlist', { userid: userId, page: 1, pagesize: 100 });
            return listOf(response).some(item => {
                if (getKugouUserCollectionType(item) !== type) return false;
                if (type === 'playlist') {
                    return String(valueOf(item, 'global_collection_id', 'globalCollectionId') || '') === String(id)
                        || String(valueOf(item, 'listid', 'list_id') || '') === String(id);
                }
                return String(valueOf(item, 'musiclib_id', 'musicLibId', 'album_id', 'albumId', 'list_create_listid') || '') === String(id);
            });
        },
    },
    recommendations: {
        async getDailySongs() {
            const response = await requestKugou('everyday_recommend');
            return songListOf(response).map(normalizeKugouSong).filter(song => song.id);
        },
        async getPersonalFm() {
            const response = await requestKugou('personal_fm');
            return songListOf(response).map(normalizeKugouSong).filter(song => song.id);
        },
        async getRecommendedCollections(limit) {
            const pagesize = Math.min(Math.max(Math.floor(limit) || KUGOU_RECOMMENDATION_PAGE_SIZE, 1), KUGOU_RECOMMENDATION_PAGE_SIZE);
            const collections = await Promise.all(KUGOU_RECOMMENDATION_CARDS.map(async card => {
                try {
                    const { response, songs } = await getKugouRecommendationCard(card.id, pagesize);
                    return songs.length > 0 ? createKugouRecommendationCollection(card, response, songs) : null;
                } catch (error) {
                    console.warn('[KugouProvider] recommendation-card:failed', {
                        cardId: card.id,
                        ...errorFields(error),
                    });
                    return null;
                }
            }));
            return collections.filter((collection): collection is ProviderCollection => Boolean(collection));
        },
        async getHistoryEntries() {
            const response = await requestKugou('everyday_history', { mode: 'list' });
            kugouHistoryNameByDate.clear();
            return normalizeKugouHistoryEntries(response);
        },
        async getHistoryDates() {
            const response = await requestKugou('everyday_history', { mode: 'list' });
            kugouHistoryNameByDate.clear();
            return normalizeKugouHistoryEntries(response)
                .map(entry => String(entry.providerData?.date || entry.id))
                .filter(Boolean);
        },
        async getHistorySongs(entry) {
            const id = typeof entry === 'string' ? entry : entry.id;
            const historyName = typeof entry === 'string'
                ? await getKugouHistoryName(id)
                : String(entry.providerData?.historyName || entry.label || id);
            const response = await requestKugou('everyday_history', {
                mode: 'song',
                date: id,
                history_name: historyName,
            });
            return songListOf(response).map(normalizeKugouSong).filter(song => song.id);
        },
        async dislikeSong(id) {
            const response = await requestKugou('personal_fm', {
                action: 'garbage',
                hash: String(id),
                songid: String(id),
            });
            const replacement = songListOf(response).map(normalizeKugouSong).find(song => song.id);
            return replacement ? { replacement } : {};
        },
    },
    mutations: {
        canAddToPlaylist: canAddToKugouPlaylist,
        async likeSong(song, liked) {
            syncKugouSessionUser();
            const userId = getKugouUserId();
            // 这里静默 return 的话，omni 会把它当成 mutation 成功并翻转 likedSongIds，心形跟着变。
            if (!userId) {
                throw new OnlineProviderError('auth-required', 'KuGou session has no user id', 'kugou');
            }
            const targetHash = getKugouTrackHash(song);
            // The row noted for the song is used once and goes, whatever becomes of the request.
            const cachedLikedFileId = kugouLikedRowIds.get(targetHash);
            kugouLikedRowIds.delete(targetHash);
            kugouLikedRowsSentAt.set(targetHash, performance.now());
            const userIdKey = String(userId);
            let likedPlaylistRef = kugouLikedPlaylistRefCache.get(userIdKey);
            if (!likedPlaylistRef) {
                const playlist = await getKugouLikedPlaylist(userId);
                const listId = valueOf(playlist, 'listid', 'list_id');
                if (listId === undefined || listId === null) {
                    throw new OnlineProviderError(
                        'invalid-response',
                        'KuGou liked playlist has no listid',
                        'kugou',
                    );
                }
                likedPlaylistRef = {
                    listId,
                    globalCollectionId: valueOf(playlist, 'global_collection_id', 'globalCollectionId'),
                };
                // 库刷新会写这份缓存，mutation 先到的时候也要写，否则每次收藏都要重新拉一次歌单列表。
                rememberKugouLikedPlaylistRef(userIdKey, likedPlaylistRef);
            }
            const { listId, globalCollectionId } = likedPlaylistRef;
            if (liked) {
                await requestKugou('playlist_tracks_add', {
                    listid: String(listId),
                    data: getKugouTrackAddData(song),
                });
                if (globalCollectionId) kugouLikedTrackCache.delete(String(globalCollectionId));
                return;
            }

            if (cachedLikedFileId !== undefined) {
                await requestKugou('playlist_tracks_del', {
                    listid: String(listId),
                    fileids: String(cachedLikedFileId),
                });
                if (globalCollectionId) removeKugouPlaylistTrackCacheEntry(String(globalCollectionId), targetHash);
                return;
            }

            if (!globalCollectionId) {
                throw new OnlineProviderError(
                    'invalid-response',
                    'KuGou liked playlist is missing global_collection_id',
                    'kugou',
                );
            }

            // The song's providerData.fileId belongs to the playlist it was played from. Looking it
            // up in the liked playlist by hash is required; sending another playlist's row id deletes
            // whichever liked song happens to share that id.
            const likedCollectionId = String(globalCollectionId);
            const findLikedFileId = async (forceRefresh: boolean): Promise<MediaId | undefined> => {
                const likedTracks = await getKugouPlaylistTrackSongs(likedCollectionId, { forceRefresh });
                const likedTrack = likedTracks.find(track => getKugouTrackHash(track) === targetHash);
                const fileId = likedTrack?.sourceRef?.kind === 'online'
                    ? likedTrack.sourceRef.providerData?.fileId
                    : undefined;
                if (typeof fileId !== 'string' && typeof fileId !== 'number') return undefined;
                return String(fileId) === '' ? undefined : fileId;
            };

            // 缓存里没有就强制重拉一次再下结论，避免 10 秒窗口内的旧快照误判。
            const likedFileId = await findLikedFileId(false) ?? await findLikedFileId(true);
            if (likedFileId === undefined) {
                // 服务端的收藏歌单里本来就没有这首歌，目标状态已经达成。抛错只会让心形永远亮着、
                // 每点一次报一次错；直接返回，让上层把本地的陈旧点赞状态清掉。
                console.info('[KugouProvider] unlike:already-absent', { hash: targetHash });
                removeKugouPlaylistTrackCacheEntry(likedCollectionId, targetHash);
                return;
            }

            await requestKugou('playlist_tracks_del', {
                listid: String(listId),
                fileids: String(likedFileId),
            });
            removeKugouPlaylistTrackCacheEntry(likedCollectionId, targetHash);
        },
        async updatePlaylistTracks(operation, playlist, tracks) {
            const collection = typeof playlist === 'object' ? playlist : null;
            const listId = String(collection?.providerData?.listId || getId(playlist));
            if (operation === 'add') {
                const data = tracks.map(getKugouTrackAddData).join(',');
                await requestKugou('playlist_tracks_add', { listid: listId, data });
                return;
            }
            // fileid 是歌单内的行号：只有当 tracks 就是从这个歌单的详情里取出来的时，它才是对的。
            // 传别的歌单里的同一首歌会删掉这个歌单里碰巧同号的另一首（"我喜欢"就踩过，见 likeSong）。
            const fileids = tracks.map(getKugouTrackFileId).join(',');
            await requestKugou('playlist_tracks_del', { listid: listId, fileids });
        },
        async subscribePlaylist(playlist, subscribed) {
            const collection = typeof playlist === 'object' ? playlist : null;
            if (isKugouVirtualRecommendation(collection || undefined)) return;

            const providerData = collection?.providerData;
            const listId = String(providerData?.listId || getId(playlist));
            if (!subscribed) {
                await requestKugou('playlist_del', { listid: listId });
                return;
            }
            await requestKugou('playlist_add', {
                name: collection?.name || '',
                type: 1,
                source: 1,
                list_create_userid: String(providerData?.creatorUserId || ''),
                list_create_listid: String(providerData?.creatorListId || listId),
                list_create_gid: String(providerData?.creatorGid || ''),
            });
        },
        async subscribeAlbum(id, subscribed) {
            const userId = getKugouUserId();
            if (!userId) return;

            if (!subscribed) {
                const album = (await getKugouUserPlaylistItems(userId)).find(item => (
                    getKugouUserCollectionType(item) === 'album'
                    && String(valueOf(item, 'musiclib_id', 'musicLibId', 'album_id', 'albumId', 'list_create_listid') || '') === String(id)
                ));
                const listId = valueOf(album, 'listid', 'list_id');
                if (listId === undefined || listId === null) return;
                await requestKugou('playlist_del', { listid: String(listId) });
                return;
            }

            const rawAlbum = await getKugouAlbumDetailRaw(id);
            if (!rawAlbum) return;
            const albumId = valueOf(rawAlbum, 'album_id', 'AlbumID', 'albumId') ?? id;
            const firstAuthor = Array.isArray(rawAlbum.authors) ? rawAlbum.authors[0]?.base ?? rawAlbum.authors[0] : undefined;
            const creatorUserId = valueOf(rawAlbum, 'list_create_userid', 'create_userid', 'author_id', 'authorId', 'userid')
                ?? valueOf(firstAuthor, 'author_id', 'authorId', 'id');
            if (creatorUserId === undefined || creatorUserId === null) return;

            await requestKugou('playlist_add', {
                source: 2,
                name: String(valueOf(rawAlbum, 'name', 'album_name', 'AlbumName') || ''),
                type: 1,
                list_create_userid: String(creatorUserId),
                list_create_listid: String(albumId),
            });
        },
    },
};
